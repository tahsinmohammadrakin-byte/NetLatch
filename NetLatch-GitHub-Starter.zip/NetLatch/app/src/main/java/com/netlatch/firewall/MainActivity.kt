package com.netlatch.firewall

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 42, 28, 28)
            gravity = Gravity.TOP
            setBackgroundColor(Color.rgb(8, 17, 38))
        }

        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = value
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }

        page.addView(text("NETLATCH", 30f, Color.rgb(74, 222, 255), true))
        page.addView(text("LOCAL FIREWALL", 13f, Color.LTGRAY, true))

        val status = TextView(this).apply {
            text = "PROJECT SCAFFOLD — VPN NOT RUNNING"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(26, 48, 78))
        }
        val statusParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        statusParams.topMargin = 28
        page.addView(status, statusParams)

        page.addView(text("What is ready", 20f, Color.WHITE, true))
        page.addView(text(
            "• Android Studio project structure\n" +
            "• Android 9+ minimum support\n" +
            "• VPN service declaration (not activated)\n" +
            "• GitHub Actions workflow to build a debug APK",
            15f, Color.rgb(210, 222, 240)
        ))
        page.addView(text("What is not ready yet", 20f, Color.WHITE, true))
        page.addView(text(
            "The packet-forwarding engine and IP filtering are not implemented. " +
            "This build is only a safe starter app; it does not filter or forward traffic.",
            15f, Color.rgb(255, 196, 120)
        ))
        page.addView(text(
            "Next: add and test the packet engine before enabling the VPN. " +
            "Do not enable Android VPN lockdown with this starter build.",
            14f, Color.rgb(255, 130, 130)
        ))
        setContentView(page)
    }
}
