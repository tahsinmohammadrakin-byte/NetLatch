package com.netlatch.firewall

import android.net.VpnService

/**
 * Reserved service entry point.
 *
 * Deliberately does not establish a TUN interface yet. A VpnService that creates
 * a TUN without a complete packet-forwarding engine can interrupt all internet
 * traffic. Implement and test the engine before adding VPN activation.
 */
class NetLatchVpnService : VpnService()
