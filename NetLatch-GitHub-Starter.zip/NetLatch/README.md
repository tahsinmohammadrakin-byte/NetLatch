# NetLatch — Android starter project

This is a **starter scaffold**, not a functioning firewall yet.

## Important safety note
The VPN service is declared but intentionally does not establish a VPN tunnel. A TUN interface without a complete packet-forwarding engine can cut off internet access. This project currently does **not** block IP addresses, inspect live connections, or perform the two-second recovery cycle. Do not enable Android's "Block connections without VPN" for this starter build.

## Build an APK using a new GitHub repository

1. Download and extract `NetLatch-GitHub-Starter.zip` on your computer.
2. Sign in at https://github.com/.
3. Click **+** (top-right) → **New repository**.
4. Repository name: `NetLatch` (or another name you prefer).
5. Choose **Public** or **Private**. Either works. Select **Add a README file: OFF** because this ZIP already contains one.
6. Click **Create repository**.
7. On the new repository page, click **Add file** → **Upload files**.
8. Open the extracted `NetLatch` folder on your computer and upload its *contents* (including the `.github` folder). Do not upload only the ZIP file.
9. Wait for the files to finish uploading, enter commit message `Initial NetLatch project`, then click **Commit changes**.
10. Open the **Actions** tab. If GitHub asks to enable workflows, approve it.
11. Open **Build NetLatch APK**. A run should start after the commit. If it does not, open the workflow and click **Run workflow** → **Run workflow**.
12. Wait until the run shows a green check. Open that run, scroll to **Artifacts**, and download **NetLatch-debug-apk**.
13. Extract the downloaded artifact ZIP. Inside it, find `app-debug.apk`.
14. Transfer `app-debug.apk` to your Android phone and install it. Android may ask you to allow installation from that file manager/browser. Only install APKs you built from your own repository.

## If you are doing everything from an Android phone
GitHub's mobile website can upload files, but uploading a whole folder (especially the hidden `.github` folder) is awkward. The easiest reliable route is a computer. If you only have your phone, use GitHub's browser site in desktop mode and upload the project through a Git client that supports folders, or tell me and I will guide you through a phone-only route.

## What this scaffold contains
- Native Kotlin Android app, minimum Android 9 (API 28).
- Basic NetLatch landing screen.
- Reserved `VpnService` class (not activated).
- GitHub Actions workflow that builds a debug APK and stores it as a downloadable artifact.

## Next engineering work
Implement a reliable packet engine (TCP/UDP, IPv4/IPv6, DNS handling as chosen), IP allow/block rules, connection logging, network-change detection, and the exact recovery cycle: close tunnel immediately on a genuine network change, wait 2 seconds, then rebuild and verify. Test on the target phone and SIM before considering it safe for daily use.
